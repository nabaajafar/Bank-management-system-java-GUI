/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bankmanagment;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;


public class MyFrame extends javax.swing.JFrame {

    /**
     * Creates new form MyFrame
     */
    ResultSet rs,trs ;
    
    public MyFrame() {
        super("BANK MANAGEMENT SYSTEM");
        initComponents();
        this.loginCustomerPage1.setVisible(true);
        this.loginEmployeePage1.setVisible(false);
        this.registerCustomerPage1.setVisible(false);
        this.customerPage2.setVisible(false);
        this.transactionPage1.setVisible(false);
        this.deposit1.setVisible(false);
        this.afDeposit2.setVisible(false);
        this.withdraw1.setVisible(false);
        this.transaction1.setVisible(false);
        this.afTransfer1.setVisible(false);
        this.displayTransaction1.setVisible(false);
        this.employeePage1.setVisible(false);
        this.viewC1.setVisible(false);
        this.openC1.setVisible(false);
        this.deleteC1.setVisible(false);
        this.managerPage1.setVisible(false);
        this.showInfo1.setVisible(false);
        this.creatEmployee1.setVisible(false);
        this.transactionShown1.setVisible(false);
        this.updateCustomerC1.setVisible(false);
        
        this.add(loginCustomerPage1);
        this.add(employeePage1);
        this.add(registerCustomerPage1);
        this.add(customerPage2);
        this.add(transactionPage1);
        this.add(deposit1);
        this.add(afDeposit2);
        this.add(withdraw1);
        this.add(transaction1);
        this.add(afTransfer1);
        this.add(displayTransaction1);
        this.add(employeePage1);
        this.add(viewC1);
        this.add(openC1);
        this.add(deleteC1);
        this.add(managerPage1);
        this.add(showInfo1);
        this.add(creatEmployee1);
        this.add(transactionShown1);
        this.add(updateCustomerC1);
        
        this.loginCustomerPage1.Employeelbl.addMouseListener(
        new MouseAdapter(){

            @Override
            public void mouseClicked(MouseEvent e) {
                super.mouseClicked(e); //To change body of generated methods, choose Tools | Templates.
                loginCustomerPage1.setVisible(false);
                loginEmployeePage1.setVisible(true); 
                updateCustomerC1.setVisible(false);
            }
            
        });
        
        this.loginCustomerPage1.Creatlbl.addMouseListener(
                new MouseAdapter(){

            @Override
            public void mouseClicked(MouseEvent e) {
                super.mouseClicked(e); //To change body of generated methods, choose Tools | Templates.
                registerCustomerPage1.IDtxt.setText("");
                 registerCustomerPage1.nameCtxt.setText("");
                registerCustomerPage1.passCtxt.setText("");
                registerCustomerPage1.phontxt.setText("");
                 registerCustomerPage1.Emailtxt.setText("");
                 registerCustomerPage1.addrtxt.setText("");
                 registerCustomerPage1.DOBtxt.setText("");
                 registerCustomerPage1.userCtxt.setText("");
                 
                loginCustomerPage1.setVisible(false);
                registerCustomerPage1.setVisible(true);
                updateCustomerC1.setVisible(false);
            }});
        
        this.registerCustomerPage1.OKR.addMouseListener(new MouseAdapter(){

            @Override
            public void mouseClicked(MouseEvent e) {
                super.mouseClicked(e); //To change body of generated methods, choose Tools | Templates.
             
                
            String url = "jdbc:mysql://localhost/bank1?useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC";
            String db_user = "root";
            String db_pass = "1234";
            try {
                Connection con = DriverManager.getConnection(url, db_user, db_pass);

                //register a user
                int xID = Integer.parseInt(registerCustomerPage1.IDtxt.getText());
                String xname = registerCustomerPage1.nameCtxt.getText();
                String xpass = registerCustomerPage1.passCtxt.getText();
                String xphone = registerCustomerPage1.phontxt.getText();
                String xemail = registerCustomerPage1.Emailtxt.getText();
                String xaddress = registerCustomerPage1.addrtxt.getText();
                String xDOB = registerCustomerPage1.DOBtxt.getText();
           
                String sql = String.format("Insert into customer"
                        + "(ID,name,Address,Email,DOB,password,phone)"
                        + "values('%s','%s','%s','%s','%s','%s','%s');", xID,xname,
                        xaddress, xemail, xDOB, xpass,xphone);
                //two lines are important
                Statement s = con.createStatement();
                //use with insert , delete , update
                s.executeUpdate(sql);

            } catch (SQLException ex) {
                System.out.println(ex.getMessage());
            }
        
            }
            
        });
        
        this.loginCustomerPage1.logcbtn.addMouseListener(new MouseAdapter(){

            @Override
            public void mouseClicked(MouseEvent e) {
                super.mouseClicked(e); //To change body of generated methods, choose Tools | Templates.
             
           String url = "jdbc:mysql://localhost/bank1?useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC";
            String db_user = "root";
            String db_pass = "1234";
           
            try {
                Connection con = DriverManager.getConnection(url, db_user, db_pass);

                //register a user
                String name = loginCustomerPage1.nametxt.getText();

                String xpass = loginCustomerPage1.passtxt.getText();
               
               String query="Select ID, password from customer";
               
                
                //two lines are important
                Statement s = con.createStatement();
                // Statement s = cont.createStatement();
                 rs = s.executeQuery(query);
                 boolean flag = false ;
                 while(rs.next()){//change it
                if(xpass.equals(rs.getString("password"))&&name.equals(rs.getString("ID"))){
                    
                    flag=true;
                     loginCustomerPage1.setVisible(false);
                     loginEmployeePage1.setVisible(false);
                     registerCustomerPage1.setVisible(false);
                     customerPage2.setVisible(true);
                     transactionPage1.setVisible(false);
                     deposit1.setVisible(false);
                     afDeposit2.setVisible(false);
                     withdraw1.setVisible(false);
                     transaction1.setVisible(false);
                     afTransfer1.setVisible(false);
                     displayTransaction1.setVisible(false);
                     employeePage1.setVisible(false);
                     viewC1.setVisible(false);
                     openC1.setVisible(false);
                     deleteC1.setVisible(false);
                 }
                 }//until here
                 if(flag == false)
                           JOptionPane.showMessageDialog(rootPane,"ID or password is not correct!!!","Login",JOptionPane.ERROR_MESSAGE);
            

            } catch (SQLException ex) {
                System.out.println(ex.getMessage());
            }
            
            }
            
        });
        
        this.loginEmployeePage1.BackEtoC.addMouseListener(
                new MouseAdapter(){

            @Override
            public void mouseClicked(MouseEvent e) {
                super.mouseClicked(e); //To change body of generated methods, choose Tools | Templates.
                loginCustomerPage1.setVisible(true);
                loginEmployeePage1.setVisible(false);
                updateCustomerC1.setVisible(false);
            }      
               });
        this.registerCustomerPage1.BackR.addMouseListener(
                new MouseAdapter(){

            @Override
            public void mouseClicked(MouseEvent e) {
                super.mouseClicked(e); //To change body of generated methods, choose Tools | Templates.
                loginCustomerPage1.setVisible(true);
                registerCustomerPage1.setVisible(false);
                updateCustomerC1.setVisible(false);
            }
                    
                });
        this.customerPage2.transactionbtn.addMouseListener(
                new MouseAdapter(){

            @Override
            public void mouseClicked(MouseEvent e) {
                super.mouseClicked(e); //To change body of generated methods, choose Tools | Templates.
                loginCustomerPage1.setVisible(false);
                loginEmployeePage1.setVisible(false);
                registerCustomerPage1.setVisible(false);
                customerPage2.setVisible(false);
                transactionPage1.setVisible(true);
                updateCustomerC1.setVisible(false);
            }
                    
                });
        this.customerPage2.logoutbtn.addMouseListener(new MouseAdapter(){

            @Override
            public void mouseClicked(MouseEvent e) {
                super.mouseClicked(e); //To change body of generated methods, choose Tools | Templates.
                loginCustomerPage1.nametxt.setText("");
                loginCustomerPage1.passtxt.setText("");
                
                loginCustomerPage1.setVisible(true);
                loginEmployeePage1.setVisible(false);
                registerCustomerPage1.setVisible(false);
                customerPage2.setVisible(false);
                transactionPage1.setVisible(false);
                deposit1.setVisible(false);
                afDeposit2.setVisible(false);
                withdraw1.setVisible(false);
                transaction1.setVisible(false);
                afTransfer1.setVisible(false);
                displayTransaction1.setVisible(false);
                employeePage1.setVisible(false);
                viewC1.setVisible(false);
                openC1.setVisible(false);
                deleteC1.setVisible(false);
                managerPage1.setVisible(false);
                showInfo1.setVisible(false);
                creatEmployee1.setVisible(false);
                transactionShown1.setVisible(false);
                updateCustomerC1.setVisible(false);
            }
            
        });
        this.transactionPage1.backlbl.addMouseListener(new MouseAdapter(){

            @Override
            public void mouseClicked(MouseEvent e) {
                super.mouseClicked(e); //To change body of generated methods, choose Tools | Templates.
                loginCustomerPage1.setVisible(false);
                loginEmployeePage1.setVisible(false);
                registerCustomerPage1.setVisible(false);
                customerPage2.setVisible(true);
                transactionPage1.setVisible(false);
                deposit1.setVisible(false);
                afDeposit2.setVisible(false);
                withdraw1.setVisible(false);
                transaction1.setVisible(false);
                afTransfer1.setVisible(false);
                displayTransaction1.setVisible(false);
                employeePage1.setVisible(false);
                viewC1.setVisible(false);
                openC1.setVisible(false);
                deleteC1.setVisible(false);
                managerPage1.setVisible(false);
                showInfo1.setVisible(false);
                creatEmployee1.setVisible(false);
                transactionShown1.setVisible(false);
                updateCustomerC1.setVisible(false);
            }
            
        });
        this.transactionPage1.logoutlbl.addMouseListener(new MouseAdapter(){

            @Override
            public void mouseClicked(MouseEvent e) {
                super.mouseClicked(e); //To change body of generated methods, choose Tools | Templates.
                loginCustomerPage1.nametxt.setText("");
                loginCustomerPage1.passtxt.setText("");
                
                loginCustomerPage1.setVisible(true);
                loginEmployeePage1.setVisible(false);
                registerCustomerPage1.setVisible(false);
                customerPage2.setVisible(false);
                transactionPage1.setVisible(false);
                deposit1.setVisible(false);
                afDeposit2.setVisible(false);
                withdraw1.setVisible(false);
                transaction1.setVisible(false);
                afTransfer1.setVisible(false);
                displayTransaction1.setVisible(false);
                employeePage1.setVisible(false);
                viewC1.setVisible(false);
                openC1.setVisible(false);
                deleteC1.setVisible(false);
                managerPage1.setVisible(false);
                showInfo1.setVisible(false);
                creatEmployee1.setVisible(false);
                transactionShown1.setVisible(false);
                updateCustomerC1.setVisible(false);
            }
            
        });
        
        this.transactionPage1.depositbtn.addMouseListener(new MouseAdapter(){

            @Override
            public void mouseClicked(MouseEvent e) {
                super.mouseClicked(e); //To change body of generated methods, choose Tools | Templates.
                loginCustomerPage1.setVisible(false);
                loginEmployeePage1.setVisible(false);
                registerCustomerPage1.setVisible(false);
                customerPage2.setVisible(false);
                transactionPage1.setVisible(false);
                deposit1.setVisible(true);
                afDeposit2.setVisible(false);
                withdraw1.setVisible(false);
                transaction1.setVisible(false);
                afTransfer1.setVisible(false);
                displayTransaction1.setVisible(false);
                employeePage1.setVisible(false);
                viewC1.setVisible(false);
                openC1.setVisible(false);
                deleteC1.setVisible(false);
                managerPage1.setVisible(false);
                showInfo1.setVisible(false);
                creatEmployee1.setVisible(false);
                transactionShown1.setVisible(false);
                updateCustomerC1.setVisible(false);
            }
            
        });
        
        this.deposit1.backlbl.addMouseListener(new MouseAdapter(){

            @Override
            public void mouseClicked(MouseEvent e) {
                super.mouseClicked(e); //To change body of generated methods, choose Tools | Templates.
                loginCustomerPage1.setVisible(false);
                loginEmployeePage1.setVisible(false);
                registerCustomerPage1.setVisible(false);
                customerPage2.setVisible(false);
                transactionPage1.setVisible(true);
                deposit1.setVisible(false);
                afDeposit2.setVisible(false);
                withdraw1.setVisible(false);
                transaction1.setVisible(false);
                afTransfer1.setVisible(false);
                displayTransaction1.setVisible(false);
                employeePage1.setVisible(false);
                viewC1.setVisible(false);
                openC1.setVisible(false);
                deleteC1.setVisible(false);
                managerPage1.setVisible(false);
                showInfo1.setVisible(false);
                creatEmployee1.setVisible(false);
                transactionShown1.setVisible(false);
                updateCustomerC1.setVisible(false);
            }
            
        });
        this.deposit1.confirmbtn.addMouseListener(new MouseAdapter(){

            @Override
            public void mouseClicked(MouseEvent e) {
                super.mouseClicked(e); //To change body of generated methods, choose Tools | Templates.
               double total=0;
            String url = "jdbc:mysql://localhost/bank1?useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC";
            String db_user = "root";
            String db_pass = "1234";
            try {
                Connection con = DriverManager.getConnection(url, db_user, db_pass);
               
                double xbalance = Double.parseDouble(deposit1.moneytxt.getText());
                      
              int xID=Integer.parseInt(loginCustomerPage1.nametxt.getText());
                String query="Select balance from customer where ID="+xID;
                
                Statement s = con.createStatement();
                // Statement s = cont.createStatement();
                 rs = s.executeQuery(query);
                 if(rs.next()){
                     if(rs.getString("balance")==null){
                          String sql = String.format("Update customer set balance="+xbalance
                       + "where ID="+xID);
                s = con.createStatement();
                //use with insert , delete , update
               
                s.executeUpdate(sql);
                
                 String Type="deposit";
                String hsql = String.format("Insert into history"
                        + "(custID,type,amount,otherAccount)"
                        + "values('%s','%s','%s','%s');", xID,
                        Type, xbalance," ");
                s.executeUpdate(hsql);
                 total=Double.parseDouble(deposit1.moneytxt.getText());
                         
                     }else{
                  total=Double.parseDouble(rs.getString("balance"))+xbalance;

                 
           
               String sql = String.format("Update customer set balance="+total
                       + "where ID="+xID);
                s = con.createStatement();
                //use with insert , delete , update
               
                s.executeUpdate(sql);
                
                 String Type="deposit";
                String hsql = String.format("Insert into history"
                        + "(custID,type,amount,otherAccount)"
                        + "values('%s','%s','%s','%s');", xID,
                        Type, xbalance," ");
                s.executeUpdate(hsql);
                
             // JOptionPane.showMessageDialog(null, "NEW Balance: "+total);
                     }
                      
                 loginCustomerPage1.setVisible(false);
                loginEmployeePage1.setVisible(false);
                registerCustomerPage1.setVisible(false);
                customerPage2.setVisible(false);
                transactionPage1.setVisible(false);
                deposit1.setVisible(false);
                afDeposit2.setVisible(true);
                withdraw1.setVisible(false);
                transaction1.setVisible(false);
                afTransfer1.setVisible(false);
                displayTransaction1.setVisible(false);
                employeePage1.setVisible(false);
                viewC1.setVisible(false);
                openC1.setVisible(false);
                deleteC1.setVisible(false);
                managerPage1.setVisible(false);
                showInfo1.setVisible(false);
                creatEmployee1.setVisible(false);
                transactionShown1.setVisible(false);
                updateCustomerC1.setVisible(false);
                afDeposit2.balancetxt.setText(""+total);
                 }

            }
            catch (SQLException ex) {
                System.out.println(ex.getMessage());
            }
            
               
            }
            
        });

        this.afDeposit2.continuebtn.addMouseListener(new MouseAdapter(){

            @Override
            public void mouseClicked(MouseEvent e) {
                super.mouseClicked(e); //To change body of generated methods, choose Tools | Templates.
                
                loginCustomerPage1.setVisible(false);
                loginEmployeePage1.setVisible(false);
                registerCustomerPage1.setVisible(false);
                customerPage2.setVisible(false);
                transactionPage1.setVisible(true);
                deposit1.setVisible(false);
                afDeposit2.setVisible(false);
                withdraw1.setVisible(false);
                transaction1.setVisible(false);
                afTransfer1.setVisible(false);
                displayTransaction1.setVisible(false);
                employeePage1.setVisible(false);
                viewC1.setVisible(false);
                openC1.setVisible(false);
                deleteC1.setVisible(false);
                managerPage1.setVisible(false);
                showInfo1.setVisible(false);
                creatEmployee1.setVisible(false);
                transactionShown1.setVisible(false);
                updateCustomerC1.setVisible(false);
            }
            
        });
        this.afDeposit2.logoutlbl.addMouseListener(new MouseAdapter(){ 

            @Override
            public void mouseClicked(MouseEvent e) {
                super.mouseClicked(e); //To change body of generated methods, choose Tools | Templates.
                loginCustomerPage1.nametxt.setText("");
                loginCustomerPage1.passtxt.setText("");
                
                loginCustomerPage1.setVisible(true);
                loginEmployeePage1.setVisible(false);
                registerCustomerPage1.setVisible(false);
                customerPage2.setVisible(false);
                transactionPage1.setVisible(false);
                deposit1.setVisible(false);
                afDeposit2.setVisible(false);
                withdraw1.setVisible(false);
                transaction1.setVisible(false);
                afTransfer1.setVisible(false);
                displayTransaction1.setVisible(false);
                employeePage1.setVisible(false);
                viewC1.setVisible(false);
                openC1.setVisible(false);
                deleteC1.setVisible(false);
                managerPage1.setVisible(false);
                showInfo1.setVisible(false);
                creatEmployee1.setVisible(false);
                transactionShown1.setVisible(false);
                updateCustomerC1.setVisible(false);
            }
            
        });
        
        this.transactionPage1.withdrawbtn.addMouseListener(new MouseAdapter(){

            @Override
            public void mouseClicked(MouseEvent e) {
                super.mouseClicked(e); //To change body of generated methods, choose Tools | Templates.
                loginCustomerPage1.setVisible(false);
                loginEmployeePage1.setVisible(false);
                registerCustomerPage1.setVisible(false);
                customerPage2.setVisible(false);
                transactionPage1.setVisible(false);
                deposit1.setVisible(false);
                afDeposit2.setVisible(false);
                withdraw1.setVisible(true);
                transaction1.setVisible(false);
                afTransfer1.setVisible(false);
                displayTransaction1.setVisible(false);
                employeePage1.setVisible(false);
                viewC1.setVisible(false);
                openC1.setVisible(false);
                deleteC1.setVisible(false);
                managerPage1.setVisible(false);
                showInfo1.setVisible(false);
                creatEmployee1.setVisible(false);
                transactionShown1.setVisible(false);
                updateCustomerC1.setVisible(false);
            }
            
        });
       this.withdraw1.backlbl.addMouseListener(new MouseAdapter(){

            @Override
            public void mouseClicked(MouseEvent e) {
                super.mouseClicked(e); //To change body of generated methods, choose Tools | Templates.
                loginCustomerPage1.setVisible(false);
                loginEmployeePage1.setVisible(false);
                registerCustomerPage1.setVisible(false);
                customerPage2.setVisible(false);
                transactionPage1.setVisible(true);
                deposit1.setVisible(false);
                afDeposit2.setVisible(false);
                withdraw1.setVisible(false);
                transaction1.setVisible(false);
                afTransfer1.setVisible(false);
                displayTransaction1.setVisible(false);
                employeePage1.setVisible(false);
                viewC1.setVisible(false);
                openC1.setVisible(false);
                deleteC1.setVisible(false);
                managerPage1.setVisible(false);
                showInfo1.setVisible(false);
                creatEmployee1.setVisible(false);
                transactionShown1.setVisible(false);
                updateCustomerC1.setVisible(false);
            }
        
    });
       this.withdraw1.confirmbtn.addMouseListener(new MouseAdapter(){

            @Override
            public void mouseClicked(MouseEvent e) {
                super.mouseClicked(e); //To change body of generated methods, choose Tools | Templates.
               double total=0;
            String url = "jdbc:mysql://localhost/bank1?useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC";
            String db_user = "root";
            String db_pass = "1234";
            try {
                Connection con = DriverManager.getConnection(url, db_user, db_pass);
                
                
                int xbalance = Integer.parseInt(withdraw1.moneytxt.getText());
                    int xID=  Integer.parseInt(loginCustomerPage1.nametxt.getText());
              
                String query="Select balance from customer where ID="+xID;
                
                Statement s = con.createStatement();
                 rs = s.executeQuery(query);
                 
                 if(rs.next()){
                     if(rs.getString("balance")==null){
                         JOptionPane.showMessageDialog(null,"Sorry ,Your balnce = 0,0");
                     }
                     else{
                 double curentbalance=(Double.parseDouble(rs.getString("balance")));
                 
                 if(curentbalance >= xbalance){
                 
                  total=curentbalance-xbalance;

                 
           
               String sql = String.format("Update customer set balance="+total
                       + "where ID="+xID );
                s = con.createStatement();
                //use with insert , delete , update
                s.executeUpdate(sql);
                
                String Type="withdraw";
                String hsql = String.format("Insert into history"
                        + "(custID,type,amount,otherAccount)"
                        + "values('%s','%s','%s','%s');",xID,
                        Type, xbalance,"  ");
                s.executeUpdate(hsql);
                loginCustomerPage1.setVisible(false);
                loginEmployeePage1.setVisible(false);
                registerCustomerPage1.setVisible(false);
                customerPage2.setVisible(false);
                transactionPage1.setVisible(false);
                deposit1.setVisible(false);
                afDeposit2.setVisible(true);
                withdraw1.setVisible(false);
                transaction1.setVisible(false);
                afTransfer1.setVisible(false);
                displayTransaction1.setVisible(false);
                employeePage1.setVisible(false);
                viewC1.setVisible(false);
                openC1.setVisible(false);
                deleteC1.setVisible(false);
                managerPage1.setVisible(false);
                showInfo1.setVisible(false);
                creatEmployee1.setVisible(false);
                transactionShown1.setVisible(false);
                updateCustomerC1.setVisible(false);
                afDeposit2.balancetxt.setText(""+total);
              
                 }
                 else if(curentbalance < xbalance)
                     JOptionPane.showMessageDialog(null, "Balance dose not enough !");
  
               
                 }}
              
            }
            catch (SQLException ex) {
                System.out.println(ex.getMessage());
            }
            
                
            }
           
       });
       this.transactionPage1.transferbtn.addMouseListener(new MouseAdapter(){

            @Override
            public void mouseClicked(MouseEvent e) {
                super.mouseClicked(e); //To change body of generated methods, choose Tools | Templates.
                loginCustomerPage1.setVisible(false);
                loginEmployeePage1.setVisible(false);
                registerCustomerPage1.setVisible(false);
                customerPage2.setVisible(false);
                transactionPage1.setVisible(false);
                deposit1.setVisible(false);
                afDeposit2.setVisible(false);
                withdraw1.setVisible(false);
                transaction1.setVisible(true);
                afTransfer1.setVisible(false);
                displayTransaction1.setVisible(false);
                employeePage1.setVisible(false);
                viewC1.setVisible(false);
                openC1.setVisible(false);
                deleteC1.setVisible(false);
                managerPage1.setVisible(false);
                showInfo1.setVisible(false);
                creatEmployee1.setVisible(false);
                transactionShown1.setVisible(false);
                updateCustomerC1.setVisible(false);
            }
           
       });
       this.transaction1.backlbl.addMouseListener(new MouseAdapter(){

            @Override
            public void mouseClicked(MouseEvent e) {
                super.mouseClicked(e); //To change body of generated methods, choose Tools | Templates.
                loginCustomerPage1.setVisible(false);
                loginEmployeePage1.setVisible(false);
                registerCustomerPage1.setVisible(false);
                customerPage2.setVisible(false);
                transactionPage1.setVisible(true);
                deposit1.setVisible(false);
                afDeposit2.setVisible(false);
                withdraw1.setVisible(false);
                transaction1.setVisible(false);
                afTransfer1.setVisible(false);
                displayTransaction1.setVisible(false);
                employeePage1.setVisible(false);
                viewC1.setVisible(false);
                openC1.setVisible(false);
                deleteC1.setVisible(false);
                managerPage1.setVisible(false);
                showInfo1.setVisible(false);
                creatEmployee1.setVisible(false);
                transactionShown1.setVisible(false);
                updateCustomerC1.setVisible(false);
            }
           
       });
       
       
       this.afTransfer1.backlbl.addMouseListener(new MouseAdapter(){

            @Override
            public void mouseClicked(MouseEvent e) {
                super.mouseClicked(e); //To change body of generated methods, choose Tools | Templates.
                loginCustomerPage1.setVisible(false);
                loginEmployeePage1.setVisible(false);
                registerCustomerPage1.setVisible(false);
                customerPage2.setVisible(false);
                transactionPage1.setVisible(false);
                deposit1.setVisible(false);
                afDeposit2.setVisible(false);
                withdraw1.setVisible(false);
                transaction1.setVisible(true);
                afTransfer1.setVisible(false);
                displayTransaction1.setVisible(false);
                employeePage1.setVisible(false);
                viewC1.setVisible(false);
                openC1.setVisible(false);
                deleteC1.setVisible(false);
                managerPage1.setVisible(false);
                showInfo1.setVisible(false);
                creatEmployee1.setVisible(false);
                transactionShown1.setVisible(false);
                updateCustomerC1.setVisible(false);
            }
           
       });
       this.transaction1.continuebtn.addMouseListener(new MouseAdapter(){

            @Override
            public void mouseClicked(MouseEvent e) {
                super.mouseClicked(e); //To change body of generated methods, choose Tools | Templates.4
             //   double sub=0;
             
                String url = "jdbc:mysql://localhost/bank1?useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC";
             String db_user = "root";
            String db_pass = "1234";
            try {
               Connection con = DriverManager.getConnection(url, db_user, db_pass);
                Connection conT = DriverManager.getConnection(url, db_user, db_pass);
                
                int xID = Integer.parseInt(loginCustomerPage1.nametxt.getText());
                int tID = Integer.parseInt(transaction1.accounttxt.getText());
                
                int xbalance = Integer.parseInt(transaction1.moneytxt.getText());
                      
              
                String query="Select balance from `bank1`.`customer` where ID="+xID;
                
                 
                String tquery="Select balance from `bank1`.`customer` where ID="+tID;
                
                Statement s = conT.createStatement();
                Statement Ts = con.createStatement();
                
                 trs = Ts.executeQuery(tquery); 
               
                  rs = s.executeQuery(query);
                 
                  
                 
                 
                 boolean flag=true;
                 if(rs.next() && trs.next()){
                      
                      double curentbalance=(Double.parseDouble(rs.getString("balance")));
                       double tbalance=(Double.parseDouble(trs.getString("balance")));
                     if(curentbalance >= xbalance){
                 double subb=curentbalance-xbalance;
                 double tran=tbalance+xbalance;

                 
           
               String sql = String.format("Update `bank1`.`customer` set balance="+subb
                       + "where id="+xID );
               
               String tsql = String.format("Update `bank1`.`customer` set balance="+tran
                       + "where id="+tID );
               s.executeUpdate(sql);
               Ts.executeUpdate(tsql);
               
                
                String Type="transfer";
                String hsql = String.format("Insert into `bank1`.`history`"
                        + "(custID,Type,Amount,otherAccount)"
                        + "values('%s','%s','%s','%s');", xID,
                        Type, xbalance,tID);
                s.executeUpdate(hsql);
                
               
                flag=false;
               afDeposit2.balancetxt.setText(""+subb);
               loginCustomerPage1.setVisible(false);
                loginEmployeePage1.setVisible(false);
                registerCustomerPage1.setVisible(false);
                customerPage2.setVisible(false);
                transactionPage1.setVisible(false);
                deposit1.setVisible(false);
                afDeposit2.setVisible(true);
                withdraw1.setVisible(false);
                transaction1.setVisible(false);
                afTransfer1.setVisible(false);
                displayTransaction1.setVisible(false);
                employeePage1.setVisible(false);
                viewC1.setVisible(false);
                deleteC1.setVisible(false);
                managerPage1.setVisible(false);
                showInfo1.setVisible(false);
                creatEmployee1.setVisible(false);
                transactionShown1.setVisible(false);
                updateCustomerC1.setVisible(false);
               
                 }
                     else
                     JOptionPane.showMessageDialog(null, "Balance dose not enough !");
               //JOpt
                 }
                 else if(flag)
                     JOptionPane.showMessageDialog(null, "No one has this ID !");
     
            }
            catch (SQLException ex) {
                System.out.println(ex.getMessage());
            }
              
            }
           
       
       });
       
       this.afTransfer1.confirmbtn.addMouseListener(new MouseAdapter(){

            @Override
            public void mouseClicked(MouseEvent e) {
                super.mouseClicked(e); //To change body of generated methods, choose Tools | Templates.
               afTransfer1.accountxt1.setText(transaction1.accounttxt.getText());
               afTransfer1.moneyttxt.setText(transaction1.moneytxt.getText());
                
                loginCustomerPage1.setVisible(false);
                loginEmployeePage1.setVisible(false);
                registerCustomerPage1.setVisible(false);
                customerPage2.setVisible(false);
                transactionPage1.setVisible(false);
                deposit1.setVisible(false);
                afDeposit2.setVisible(true);
                withdraw1.setVisible(false);
                transaction1.setVisible(false);
                afTransfer1.setVisible(false);
                displayTransaction1.setVisible(false);
                employeePage1.setVisible(false);
                viewC1.setVisible(false);
                deleteC1.setVisible(false);
                managerPage1.setVisible(false);
                showInfo1.setVisible(false);
                creatEmployee1.setVisible(false);
                transactionShown1.setVisible(false);
                updateCustomerC1.setVisible(false);
            }
           
       
       });
       
       this.customerPage2.Historybtn.addMouseListener(new MouseAdapter(){

            @Override
            public void mouseClicked(MouseEvent e) {
                super.mouseClicked(e); //To change body of generated methods, choose Tools | Templates.
                displayTransaction1.TextArea.setText("");
                String url = "jdbc:mysql://localhost/bank1?useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC";
                String db_user = "root";
                String db_pass = "1234";
            try {
                Connection con = DriverManager.getConnection(url, db_user, db_pass);
                
                int xID = Integer.parseInt(loginCustomerPage1.nametxt.getText());
                
               // String query="Select ID,name,password,balance,phone,Email,Address,Account where ID="+xID;
                
                Statement s = con.createStatement();
               
                 //rs = s.executeQuery(query);
                 
                 rs = s.executeQuery("Select * from `bank1`.`history` where custID="+xID );
                 String st="ID       Type       Amount    OtherAccount  \n----------------------------------------------\n";
                 displayTransaction1.TextArea.append(st);
                 while(rs.next()){
                 int id=rs.getInt("custID");
                 String type=rs.getString("type");
                 //String password=rs.getString("");
                 Double amount=rs.getDouble("amount");
                 String other=rs.getString("otherAccount");
                 //String Email=rs.getString("Email");
                 //String Address=rs.getString("Address");
                 //String Account=rs.getString("Account");
                 
                 String stt=id+"       "+type+"      "+amount+"           "+other+
                         "   ";
                 displayTransaction1.TextArea.append(stt+"\n");
                 //JOptionPane.showMessageDialog(null,"work" );
                 }
                 
               
               
               
               
               
                //s = con.createStatement();
                //use with insert , delete , update
                //s.executeUpdate(sql);
               
loginCustomerPage1.setVisible(false);
                loginEmployeePage1.setVisible(false);
                registerCustomerPage1.setVisible(false);
                customerPage2.setVisible(false);
                transactionPage1.setVisible(false);
                deposit1.setVisible(false);
                afDeposit2.setVisible(false);
                withdraw1.setVisible(false);
                transaction1.setVisible(false);
                afTransfer1.setVisible(false);
                displayTransaction1.setVisible(true);
                employeePage1.setVisible(false);
                viewC1.setVisible(false);
                openC1.setVisible(false);
                deleteC1.setVisible(false);
                managerPage1.setVisible(false);
                showInfo1.setVisible(false);
                creatEmployee1.setVisible(false);
                transactionShown1.setVisible(false);
                updateCustomerC1.setVisible(false);
            }
            catch (SQLException ex) {
                System.out.println(ex.getMessage());
            }
            /*loginCustomerPage1.setVisible(false);
                loginEmployeePage1.setVisible(false);
                registerCustomerPage1.setVisible(false);
                customerPage2.setVisible(false);
                transactionPage1.setVisible(false);
                deposit1.setVisible(false);
                afDeposit2.setVisible(false);
                withdraw1.setVisible(false);
                transaction1.setVisible(false);
                afTransfer1.setVisible(false);
                displayTransaction1.setVisible(true);
                employeePage1.setVisible(false);
                viewC1.setVisible(false);
                openC1.setVisible(false);
                deleteC1.setVisible(false);
                managerPage1.setVisible(false);
                showInfo1.setVisible(false);
                creatEmployee1.setVisible(false);
                transactionShown1.setVisible(false);
                updateCustomerC1.setVisible(false);*/
             
            }
           
       });
       this.displayTransaction1.backlbl.addMouseListener(new MouseAdapter(){

            @Override
            public void mouseClicked(MouseEvent e) {
                super.mouseClicked(e); //To change body of generated methods, choose Tools | Templates.
                loginCustomerPage1.setVisible(false);
                loginEmployeePage1.setVisible(false);
                registerCustomerPage1.setVisible(false);
                customerPage2.setVisible(true);
                transactionPage1.setVisible(false);
                deposit1.setVisible(false);
                afDeposit2.setVisible(false);
                withdraw1.setVisible(false);
                transaction1.setVisible(false);
                afTransfer1.setVisible(false);
                displayTransaction1.setVisible(false);
                employeePage1.setVisible(false);
                viewC1.setVisible(false);
                openC1.setVisible(false);
                deleteC1.setVisible(false);
                managerPage1.setVisible(false);
                showInfo1.setVisible(false);
                creatEmployee1.setVisible(false);
                transactionShown1.setVisible(false);
                updateCustomerC1.setVisible(false);
            }
           
       });
       this.loginEmployeePage1.loginEbtn.addMouseListener(new MouseAdapter(){

            @Override
            public void mouseClicked(MouseEvent e) {
                super.mouseClicked(e); //To change body of generated methods, choose Tools | Templates.
                if("1234".equals(loginEmployeePage1.passEtxt.getText())&&"1234".equals(loginEmployeePage1.nameEtxt.getText())){
                    
                loginCustomerPage1.setVisible(false);
                loginEmployeePage1.setVisible(false);
                registerCustomerPage1.setVisible(false);
                customerPage2.setVisible(false);
                transactionPage1.setVisible(false);
                deposit1.setVisible(false);
                afDeposit2.setVisible(false);
                withdraw1.setVisible(false);
                transaction1.setVisible(false);
                afTransfer1.setVisible(false);
                displayTransaction1.setVisible(false);
                employeePage1.setVisible(false);
                viewC1.setVisible(false);
                openC1.setVisible(false);
                deleteC1.setVisible(false);
                managerPage1.setVisible(true);
                showInfo1.setVisible(false);
                creatEmployee1.setVisible(false);
                transactionShown1.setVisible(false);
                updateCustomerC1.setVisible(false);
                }
               else{
                    
           String url = "jdbc:mysql://localhost/bank1?useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC";
            String db_user = "root";
            String db_pass = "1234";
           
            try {
                Connection con = DriverManager.getConnection(url, db_user, db_pass);

                //register a user
                String name = loginEmployeePage1.nameEtxt.getText();

                String xpass = loginEmployeePage1.passEtxt.getText();
               
               String query="Select ID, password from employee";
               
                
                //two lines are important
                Statement s = con.createStatement();
                // Statement s = cont.createStatement();
                 rs = s.executeQuery(query);
                 boolean flag = false ;
                 while(rs.next()){//change it
                if(xpass.equals(rs.getString("password"))&&name.equals(rs.getString("ID"))){
                    //JOptionPane.showMessageDialog(null, "Work!!");
                    flag=true;
                     loginCustomerPage1.setVisible(false);
                loginEmployeePage1.setVisible(false);
                registerCustomerPage1.setVisible(false);
                customerPage2.setVisible(false);
                transactionPage1.setVisible(false);
                deposit1.setVisible(false);
                afDeposit2.setVisible(false);
                withdraw1.setVisible(false);
                transaction1.setVisible(false);
                afTransfer1.setVisible(false);
                displayTransaction1.setVisible(false);
                employeePage1.setVisible(true);
                viewC1.setVisible(false);
                openC1.setVisible(false);
                deleteC1.setVisible(false);
                managerPage1.setVisible(false);
                showInfo1.setVisible(false);
                creatEmployee1.setVisible(false);
                transactionShown1.setVisible(false);
                updateCustomerC1.setVisible(false);
                 }
                 }//until here
                 if(flag == false)
                           JOptionPane.showMessageDialog(rootPane,"ID or password is not correct!!!","Login",JOptionPane.ERROR_MESSAGE);
            

            } catch (SQLException ex) {
                System.out.println(ex.getMessage());
            }
                
                }
            }
           
       });
       this.employeePage1.logoutlbl.addMouseListener(new MouseAdapter(){

        @Override
            public void mouseClicked(MouseEvent e) {
                super.mouseClicked(e); //To change body of generated methods, choose Tools | Templates.
                loginEmployeePage1.nameEtxt.setText("");
                loginEmployeePage1.passEtxt.setText("");
                
                loginCustomerPage1.setVisible(false);
                loginEmployeePage1.setVisible(true);
                registerCustomerPage1.setVisible(false);
                customerPage2.setVisible(false);
                transactionPage1.setVisible(false);
                deposit1.setVisible(false);
                afDeposit2.setVisible(false);
                withdraw1.setVisible(false);
                transaction1.setVisible(false);
                afTransfer1.setVisible(false);
                displayTransaction1.setVisible(false);
                employeePage1.setVisible(false);
                viewC1.setVisible(false);
                openC1.setVisible(false);
                deleteC1.setVisible(false);
                managerPage1.setVisible(false);
                showInfo1.setVisible(false);
                creatEmployee1.setVisible(false);
                transactionShown1.setVisible(false);
                updateCustomerC1.setVisible(false);
            }
               });
       this.employeePage1.viewlbl.addMouseListener(new MouseAdapter(){

            @Override
            public void mouseClicked(MouseEvent e) {
                super.mouseClicked(e); //To change body of generated methods, choose Tools | Templates.
                loginCustomerPage1.setVisible(false);
                loginEmployeePage1.setVisible(false);
                registerCustomerPage1.setVisible(false);
                customerPage2.setVisible(false);
                transactionPage1.setVisible(false);
                deposit1.setVisible(false);
                afDeposit2.setVisible(false);
                withdraw1.setVisible(false);
                transaction1.setVisible(false);
                afTransfer1.setVisible(false);
                displayTransaction1.setVisible(false);
                employeePage1.setVisible(false);
                viewC1.setVisible(true);
                openC1.setVisible(false);
                deleteC1.setVisible(false);
                managerPage1.setVisible(false);
                showInfo1.setVisible(false);
                creatEmployee1.setVisible(false);
                transactionShown1.setVisible(false);
                updateCustomerC1.setVisible(false);
            }
           
       });
       this.viewC1.backlbl.addMouseListener(new MouseAdapter(){

            @Override
            public void mouseClicked(MouseEvent e) {
                super.mouseClicked(e); //To change body of generated methods, choose Tools | Templates.
                loginCustomerPage1.setVisible(false);
                loginEmployeePage1.setVisible(false);
                registerCustomerPage1.setVisible(false);
                customerPage2.setVisible(false);
                transactionPage1.setVisible(false);
                deposit1.setVisible(false);
                afDeposit2.setVisible(false);
                withdraw1.setVisible(false);
                transaction1.setVisible(false);
                afTransfer1.setVisible(false);
                displayTransaction1.setVisible(false);
                employeePage1.setVisible(true);
                viewC1.setVisible(false);
                openC1.setVisible(false);
                deleteC1.setVisible(false);
                managerPage1.setVisible(false);
                showInfo1.setVisible(false);
                creatEmployee1.setVisible(false);
                transactionShown1.setVisible(false);
                updateCustomerC1.setVisible(false);
            }
           
       });
       this.employeePage1.openbtn.addMouseListener(new MouseAdapter(){

            @Override
            public void mouseClicked(MouseEvent e) {
                super.mouseClicked(e); //To change body of generated methods, choose Tools | Templates.
                loginCustomerPage1.setVisible(false);
                loginEmployeePage1.setVisible(false);
                registerCustomerPage1.setVisible(false);
                customerPage2.setVisible(false);
                transactionPage1.setVisible(false);
                deposit1.setVisible(false);
                afDeposit2.setVisible(false);
                withdraw1.setVisible(false);
                transaction1.setVisible(false);
                afTransfer1.setVisible(false);
                displayTransaction1.setVisible(false);
                employeePage1.setVisible(false);
                viewC1.setVisible(false);
                openC1.setVisible(true);
                deleteC1.setVisible(false);
                managerPage1.setVisible(false);
                showInfo1.setVisible(false);
                creatEmployee1.setVisible(false);
                transactionShown1.setVisible(false);
                updateCustomerC1.setVisible(false);
            }
           
       });
       this.viewC1.openbtn.addMouseListener(new MouseAdapter(){

            @Override
            public void mouseClicked(MouseEvent e) {
                super.mouseClicked(e); //To change body of generated methods, choose Tools | Templates.
                loginCustomerPage1.setVisible(false);
                loginEmployeePage1.setVisible(false);
                registerCustomerPage1.setVisible(false);
                customerPage2.setVisible(false);
                transactionPage1.setVisible(false);
                deposit1.setVisible(false);
                afDeposit2.setVisible(false);
                withdraw1.setVisible(false);
                transaction1.setVisible(false);
                afTransfer1.setVisible(false);
                displayTransaction1.setVisible(false);
                employeePage1.setVisible(false);
                viewC1.setVisible(false);
                openC1.setVisible(true);
                deleteC1.setVisible(false);
                managerPage1.setVisible(false);
                showInfo1.setVisible(false);
                creatEmployee1.setVisible(false);
                transactionShown1.setVisible(false);
                updateCustomerC1.setVisible(false);
            }
           
       });
       this.openC1.viewlbl.addMouseListener(new MouseAdapter(){

            @Override
            public void mouseClicked(MouseEvent e) {
                super.mouseClicked(e); //To change body of generated methods, choose Tools | Templates.
                loginCustomerPage1.setVisible(false);
                loginEmployeePage1.setVisible(false);
                registerCustomerPage1.setVisible(false);
                customerPage2.setVisible(false);
                transactionPage1.setVisible(false);
                deposit1.setVisible(false);
                afDeposit2.setVisible(false);
                withdraw1.setVisible(false);
                transaction1.setVisible(false);
                afTransfer1.setVisible(false);
                displayTransaction1.setVisible(false);
                employeePage1.setVisible(false);
                viewC1.setVisible(true);
                openC1.setVisible(false);
                deleteC1.setVisible(false);
                managerPage1.setVisible(false);
                showInfo1.setVisible(false);
                creatEmployee1.setVisible(false);
                transactionShown1.setVisible(false);
                updateCustomerC1.setVisible(false);
            }
           
       });
       this.openC1.backlbl.addMouseListener(new MouseAdapter(){

            @Override
            public void mouseClicked(MouseEvent e) {
                super.mouseClicked(e); //To change body of generated methods, choose Tools | Templates.
                loginCustomerPage1.setVisible(false);
                loginEmployeePage1.setVisible(false);
                registerCustomerPage1.setVisible(false);
                customerPage2.setVisible(false);
                transactionPage1.setVisible(false);
                deposit1.setVisible(false);
                afDeposit2.setVisible(false);
                withdraw1.setVisible(false);
                transaction1.setVisible(false);
                afTransfer1.setVisible(false);
                displayTransaction1.setVisible(false);
                employeePage1.setVisible(true);
                viewC1.setVisible(false);
                openC1.setVisible(false);
                deleteC1.setVisible(false);
                managerPage1.setVisible(false);
                showInfo1.setVisible(false);
                creatEmployee1.setVisible(false);
                transactionShown1.setVisible(false);
                updateCustomerC1.setVisible(false);
            }
           
       });
       this.employeePage1.deletebtn.addMouseListener(new MouseAdapter(){

            @Override
            public void mouseClicked(MouseEvent e) {
                super.mouseClicked(e); //To change body of generated methods, choose Tools | Templates.
                loginCustomerPage1.setVisible(false);
                loginEmployeePage1.setVisible(false);
                registerCustomerPage1.setVisible(false);
                customerPage2.setVisible(false);
                transactionPage1.setVisible(false);
                deposit1.setVisible(false);
                afDeposit2.setVisible(false);
                withdraw1.setVisible(false);
                transaction1.setVisible(false);
                afTransfer1.setVisible(false);
                displayTransaction1.setVisible(false);
                employeePage1.setVisible(false);
                viewC1.setVisible(false);
                openC1.setVisible(false);
                deleteC1.setVisible(true);
                managerPage1.setVisible(false);
                showInfo1.setVisible(false);
                creatEmployee1.setVisible(false);
                transactionShown1.setVisible(false);
                updateCustomerC1.setVisible(false);
            }
           
       });
       this.openC1.deletebtn.addMouseListener(new MouseAdapter(){

            @Override
            public void mouseClicked(MouseEvent e) {
                super.mouseClicked(e); //To change body of generated methods, choose Tools | Templates.
                loginCustomerPage1.setVisible(false);
                loginEmployeePage1.setVisible(false);
                registerCustomerPage1.setVisible(false);
                customerPage2.setVisible(false);
                transactionPage1.setVisible(false);
                deposit1.setVisible(false);
                afDeposit2.setVisible(false);
                withdraw1.setVisible(false);
                transaction1.setVisible(false);
                afTransfer1.setVisible(false);
                displayTransaction1.setVisible(false);
                employeePage1.setVisible(false);
                viewC1.setVisible(false);
                openC1.setVisible(false);
                deleteC1.setVisible(true);
                managerPage1.setVisible(false);
                showInfo1.setVisible(false);
                creatEmployee1.setVisible(false);
                transactionShown1.setVisible(false);
                updateCustomerC1.setVisible(false);
            }
           
       });
       this.viewC1.deletebtn.addMouseListener(new MouseAdapter(){

            @Override
            public void mouseClicked(MouseEvent e) {
                super.mouseClicked(e); //To change body of generated methods, choose Tools | Templates.
                loginCustomerPage1.setVisible(false);
                loginEmployeePage1.setVisible(false);
                registerCustomerPage1.setVisible(false);
                customerPage2.setVisible(false);
                transactionPage1.setVisible(false);
                deposit1.setVisible(false);
                afDeposit2.setVisible(false);
                withdraw1.setVisible(false);
                transaction1.setVisible(false);
                afTransfer1.setVisible(false);
                displayTransaction1.setVisible(false);
                employeePage1.setVisible(false);
                viewC1.setVisible(false);
                openC1.setVisible(false);
                deleteC1.setVisible(true);
                managerPage1.setVisible(false);
                showInfo1.setVisible(false);
                creatEmployee1.setVisible(false);
                transactionShown1.setVisible(false);
                updateCustomerC1.setVisible(false);
            }
           
       });
       this.deleteC1.openbtn.addMouseListener(new MouseAdapter(){

            @Override
            public void mouseClicked(MouseEvent e) {
                super.mouseClicked(e); //To change body of generated methods, choose Tools | Templates.
                loginCustomerPage1.setVisible(false);
                loginEmployeePage1.setVisible(false);
                registerCustomerPage1.setVisible(false);
                customerPage2.setVisible(false);
                transactionPage1.setVisible(false);
                deposit1.setVisible(false);
                afDeposit2.setVisible(false);
                withdraw1.setVisible(false);
                transaction1.setVisible(false);
                afTransfer1.setVisible(false);
                displayTransaction1.setVisible(false);
                employeePage1.setVisible(false);
                viewC1.setVisible(false);
                openC1.setVisible(true);
                deleteC1.setVisible(false);
                managerPage1.setVisible(false);
                showInfo1.setVisible(false);
                creatEmployee1.setVisible(false);
                transactionShown1.setVisible(false);
                updateCustomerC1.setVisible(false);
            }
           
       });
       this.deleteC1.viewlbl.addMouseListener(new MouseAdapter(){

            @Override
            public void mouseClicked(MouseEvent e) {
                super.mouseClicked(e); //To change body of generated methods, choose Tools | Templates.
                loginCustomerPage1.setVisible(false);
                loginEmployeePage1.setVisible(false);
                registerCustomerPage1.setVisible(false);
                customerPage2.setVisible(false);
                transactionPage1.setVisible(false);
                deposit1.setVisible(false);
                afDeposit2.setVisible(false);
                withdraw1.setVisible(false);
                transaction1.setVisible(false);
                afTransfer1.setVisible(false);
                displayTransaction1.setVisible(false);
                employeePage1.setVisible(false);
                viewC1.setVisible(true);
                openC1.setVisible(false);
                deleteC1.setVisible(false);
                managerPage1.setVisible(false);
                showInfo1.setVisible(false);
                creatEmployee1.setVisible(false);
                transactionShown1.setVisible(false);
                updateCustomerC1.setVisible(false);
            }
           
       });
       this.deleteC1.backlbl.addMouseListener(new MouseAdapter(){

            @Override
            public void mouseClicked(MouseEvent e) {
                super.mouseClicked(e); //To change body of generated methods, choose Tools | Templates.
                loginCustomerPage1.setVisible(false);
                loginEmployeePage1.setVisible(false);
                registerCustomerPage1.setVisible(false);
                customerPage2.setVisible(false);
                transactionPage1.setVisible(false);
                deposit1.setVisible(false);
                afDeposit2.setVisible(false);
                withdraw1.setVisible(false);
                transaction1.setVisible(false);
                afTransfer1.setVisible(false);
                displayTransaction1.setVisible(false);
                employeePage1.setVisible(true);
                viewC1.setVisible(false);
                openC1.setVisible(false);
                deleteC1.setVisible(false);
                managerPage1.setVisible(false);
                showInfo1.setVisible(false);
                creatEmployee1.setVisible(false);
                transactionShown1.setVisible(false);
                updateCustomerC1.setVisible(false);
            }
           
       });
       this.managerPage1.DUbtn.addMouseListener(new MouseAdapter(){

            @Override
            public void mouseClicked(MouseEvent e) {
                super.mouseClicked(e); //To change body of generated methods, choose Tools | Templates.
                loginCustomerPage1.setVisible(false);
                loginEmployeePage1.setVisible(false);
                registerCustomerPage1.setVisible(false);
                customerPage2.setVisible(false);
                transactionPage1.setVisible(false);
                deposit1.setVisible(false);
                afDeposit2.setVisible(false);
                withdraw1.setVisible(false);
                transaction1.setVisible(false);
                afTransfer1.setVisible(false);
                displayTransaction1.setVisible(false);
                employeePage1.setVisible(false);
                viewC1.setVisible(false);
                openC1.setVisible(false);
                deleteC1.setVisible(false);
                managerPage1.setVisible(false);
                showInfo1.setVisible(true);
                creatEmployee1.setVisible(false);
                transactionShown1.setVisible(false);
                updateCustomerC1.setVisible(false);
            }
           
       });
       this.showInfo1.backbtn.addMouseListener(new MouseAdapter(){

            @Override
            public void mouseClicked(MouseEvent e) {
                super.mouseClicked(e); //To change body of generated methods, choose Tools | Templates.
                loginCustomerPage1.setVisible(false);
                loginEmployeePage1.setVisible(false);
                registerCustomerPage1.setVisible(false);
                customerPage2.setVisible(false);
                transactionPage1.setVisible(false);
                deposit1.setVisible(false);
                afDeposit2.setVisible(false);
                withdraw1.setVisible(false);
                transaction1.setVisible(false);
                afTransfer1.setVisible(false);
                displayTransaction1.setVisible(false);
                employeePage1.setVisible(false);
                viewC1.setVisible(false);
                openC1.setVisible(false);
                deleteC1.setVisible(false);
                managerPage1.setVisible(true);
                showInfo1.setVisible(false);
                creatEmployee1.setVisible(false);
                transactionShown1.setVisible(false);
                updateCustomerC1.setVisible(false);
            }
           
       });
       
       
       this.managerPage1.creatbtn.addMouseListener(new MouseAdapter(){

            @Override
            public void mouseClicked(MouseEvent e) {
                super.mouseClicked(e); //To change body of generated methods, choose Tools | Templates.
                loginCustomerPage1.setVisible(false);
                loginEmployeePage1.setVisible(false);
                registerCustomerPage1.setVisible(false);
                customerPage2.setVisible(false);
                transactionPage1.setVisible(false);
                deposit1.setVisible(false);
                afDeposit2.setVisible(false);
                withdraw1.setVisible(false);
                transaction1.setVisible(false);
                afTransfer1.setVisible(false);
                displayTransaction1.setVisible(false);
                employeePage1.setVisible(false);
                viewC1.setVisible(false);
                openC1.setVisible(false);
                deleteC1.setVisible(false);
                managerPage1.setVisible(false);
                showInfo1.setVisible(false);
                creatEmployee1.setVisible(true);
                transactionShown1.setVisible(false);
                updateCustomerC1.setVisible(false);
               }});
       
       this.creatEmployee1.backlbl.addMouseListener(new MouseAdapter(){

            @Override
            public void mouseClicked(MouseEvent e) {
                super.mouseClicked(e); //To change body of generated methods, choose Tools | Templates.
                loginCustomerPage1.setVisible(false);
                loginEmployeePage1.setVisible(false);
                registerCustomerPage1.setVisible(false);
                customerPage2.setVisible(false);
                transactionPage1.setVisible(false);
                deposit1.setVisible(false);
                afDeposit2.setVisible(false);
                withdraw1.setVisible(false);
                transaction1.setVisible(false);
                afTransfer1.setVisible(false);
                displayTransaction1.setVisible(false);
                employeePage1.setVisible(false);
                viewC1.setVisible(false);
                openC1.setVisible(false);
                deleteC1.setVisible(false);
                managerPage1.setVisible(true);
                showInfo1.setVisible(false);
                creatEmployee1.setVisible(false);
                transactionShown1.setVisible(false);
                updateCustomerC1.setVisible(false);
               }});
       
       
       this.managerPage1.logoutlbl.addMouseListener(new MouseAdapter(){

            @Override
            public void mouseClicked(MouseEvent e) {
                super.mouseClicked(e); //To change body of generated methods, choose Tools | Templates
                loginEmployeePage1.nameEtxt.setText("");
                loginEmployeePage1.passEtxt.setText("");
                
                loginCustomerPage1.setVisible(false);
                loginEmployeePage1.setVisible(true);
                registerCustomerPage1.setVisible(false);
                customerPage2.setVisible(false);
                transactionPage1.setVisible(false);
                deposit1.setVisible(false);
                afDeposit2.setVisible(false);
                withdraw1.setVisible(false);
                transaction1.setVisible(false);
                afTransfer1.setVisible(false);
                displayTransaction1.setVisible(false);
                employeePage1.setVisible(false);
                viewC1.setVisible(false);
                openC1.setVisible(false);
                deleteC1.setVisible(false);
                managerPage1.setVisible(false);
                showInfo1.setVisible(false);
                creatEmployee1.setVisible(false);
                transactionShown1.setVisible(false);
                updateCustomerC1.setVisible(false);
               }});
       
       this.transactionShown1.backlbl.addMouseListener(new MouseAdapter(){

            @Override
            public void mouseClicked(MouseEvent e) {
                super.mouseClicked(e); //To change body of generated methods, choose Tools | Templates.
                loginCustomerPage1.setVisible(false);
                loginEmployeePage1.setVisible(false);
                registerCustomerPage1.setVisible(false);
                customerPage2.setVisible(false);
                transactionPage1.setVisible(false);
                deposit1.setVisible(false);
                afDeposit2.setVisible(false);
                withdraw1.setVisible(false);
                transaction1.setVisible(false);
                afTransfer1.setVisible(false);
                displayTransaction1.setVisible(false);
                employeePage1.setVisible(false);
                viewC1.setVisible(false);
                openC1.setVisible(false);
                deleteC1.setVisible(false);
                managerPage1.setVisible(true);
                showInfo1.setVisible(false);
                creatEmployee1.setVisible(false);
                transactionShown1.setVisible(false);
                updateCustomerC1.setVisible(false);
               }});
       this.managerPage1.displaybtn.addMouseListener(new MouseAdapter(){

            @Override
            public void mouseClicked(MouseEvent e) {
                super.mouseClicked(e); //To change body of generated methods, choose Tools | Templates.
                String url = "jdbc:mysql://localhost/bank1?useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC";
                String db_user = "root";
                String db_pass = "1234";
            try {
                Connection con = DriverManager.getConnection(url, db_user, db_pass);
                
                //int xID = Integer.parseInt(loginCustomerPage1.nametxt.getText());
                
               // String query="Select ID,name,password,balance,phone,Email,Address,Account where ID="+xID;
                
                Statement s = con.createStatement();
               
                 //rs = s.executeQuery(query);
                 
                 rs = s.executeQuery("Select * from `bank1`.`history`");
                 String st="ID       Type       Amount    OtherAccount  \n----------------------------------------------\n";
                 transactionShown1.jTextArea1.append(st);
                 while(rs.next()){
                 int id=rs.getInt("custID");
                 String type=rs.getString("type");
                 //String password=rs.getString("");
                 Double amount=rs.getDouble("amount");
                 String other=rs.getString("otherAccount");
                 //String Email=rs.getString("Email");
                 //String Address=rs.getString("Address");
                 //String Account=rs.getString("Account");
                 
                 String stt=id+"       "+type+"      "+amount+"           "+other+
                         "   ";
                 transactionShown1.jTextArea1.append(stt+"\n");
                 //JOptionPane.showMessageDialog(null,"work" );
                 }
                
loginCustomerPage1.setVisible(false);
                loginEmployeePage1.setVisible(false);
                registerCustomerPage1.setVisible(false);
                customerPage2.setVisible(false);
                transactionPage1.setVisible(false);
                deposit1.setVisible(false);
                afDeposit2.setVisible(false);
                withdraw1.setVisible(false);
                transaction1.setVisible(false);
                afTransfer1.setVisible(false);
                displayTransaction1.setVisible(false);
                employeePage1.setVisible(false);
                viewC1.setVisible(false);
                openC1.setVisible(false);
                deleteC1.setVisible(false);
                managerPage1.setVisible(false);
                showInfo1.setVisible(false);
                creatEmployee1.setVisible(false);
                transactionShown1.setVisible(true);
                updateCustomerC1.setVisible(false);
            }
            catch (SQLException ex) {
                System.out.println(ex.getMessage());
            }
                
               }});
       this.customerPage2.infobtn.addMouseListener(new MouseAdapter(){

            @Override
            public void mouseClicked(MouseEvent e) {
                super.mouseClicked(e); //To change body of generated methods, choose Tools | Templates.
                int IDC=Integer.parseInt(loginCustomerPage1.nametxt.getText());
                    String url = "jdbc:mysql://localhost/bank1?useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC";
            String db_user = "root";
            String db_pass = "1234";
           
            try {
                Connection con = DriverManager.getConnection(url, db_user, db_pass);

               String query="Select * from customer where ID="+IDC;
               
                
                //two lines are important
                Statement s = con.createStatement();
                // Statement s = cont.createStatement();
                 rs = s.executeQuery(query);
                 
                 if(rs.next()){//change it

                   
                     updateCustomerC1.nametxt.setText((String) rs.getObject("name"));
                     int idd=(int) rs.getObject("ID");
                     String bd=Integer.toString((int) idd);
                     updateCustomerC1.IDtxt.setText(bd);
                     updateCustomerC1.addresstxt.setText((String) rs.getObject("Address"));
                     updateCustomerC1.emailtxt.setText((String) rs.getObject("Email"));
                     updateCustomerC1.DOBtxt.setText((String) rs.getObject("DOB"));
                     updateCustomerC1.phonetxt.setText((String) rs.getObject("phone"));
                     updateCustomerC1.passwordtxt.setText((String) rs.getObject("password"));
                 
                 }//until here
             
                loginCustomerPage1.setVisible(false);
                loginEmployeePage1.setVisible(false);
                registerCustomerPage1.setVisible(false);
                customerPage2.setVisible(false);
                transactionPage1.setVisible(false);
                deposit1.setVisible(false);
                afDeposit2.setVisible(false);
                withdraw1.setVisible(false);
                transaction1.setVisible(false);
                afTransfer1.setVisible(false);
                displayTransaction1.setVisible(false);
                employeePage1.setVisible(false);
                viewC1.setVisible(false);
                openC1.setVisible(false);
                deleteC1.setVisible(false);
                managerPage1.setVisible(false);
                showInfo1.setVisible(false);
                creatEmployee1.setVisible(false);
                transactionShown1.setVisible(false);
                updateCustomerC1.setVisible(true);
            }catch (SQLException ex) {
                System.out.println(ex.getMessage());
            }
               }});
       this.updateCustomerC1.backlbl.addMouseListener(new MouseAdapter(){

            @Override
            public void mouseClicked(MouseEvent e) {
                super.mouseClicked(e); //To change body of generated methods, choose Tools | Templates.
                loginCustomerPage1.setVisible(false);
                loginEmployeePage1.setVisible(false);
                registerCustomerPage1.setVisible(false);
                customerPage2.setVisible(true);
                transactionPage1.setVisible(false);
                deposit1.setVisible(false);
                afDeposit2.setVisible(false);
                withdraw1.setVisible(false);
                transaction1.setVisible(false);
                afTransfer1.setVisible(false);
                displayTransaction1.setVisible(false);
                employeePage1.setVisible(false);
                viewC1.setVisible(false);
                openC1.setVisible(false);
                deleteC1.setVisible(false);
                managerPage1.setVisible(false);
                showInfo1.setVisible(false);
                creatEmployee1.setVisible(false);
                transactionShown1.setVisible(false);
                updateCustomerC1.setVisible(false);
               }});
       this.deleteC1.deletbtn.addMouseListener(new MouseAdapter(){

            @Override
            public void mouseClicked(MouseEvent e) {
            String url = "jdbc:mysql://localhost/bank1?useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC";
            String db_user = "root";
            String db_pass = "1234";
            try {
                Connection con = DriverManager.getConnection(url, db_user, db_pass);
                
                int xID = Integer.parseInt(deleteC1.usertxt.getText());
                
                      
              
                String query="Select * from `bank1`.`customer` where ID="+xID;
                
                Statement s = con.createStatement();
                // Statement s = cont.createStatement();
                 rs = s.executeQuery(query);
       
               String sql = String.format("Delete from `bank1`.`customer` where ID="+xID);
               
               String Hquery="Select * from `bank1`.`history` where custID="+xID;

                 rs = s.executeQuery(Hquery);

                s.executeUpdate(sql);

               JOptionPane.showMessageDialog(null, "Customer DELETED!");
               
                 }
                

            
            catch (SQLException ex) {
                System.out.println(ex.getMessage());
            }
                 
            }
           
       });
     
       
       this.showInfo1.showebtn.addMouseListener(new MouseAdapter(){
           
            @Override
            public void mouseClicked(MouseEvent e) {
                super.mouseClicked(e); //To change body of generated methods, choose Tools | Templates.
               if(showInfo1.CustomerRadioButton.isSelected()){
                   int IDC=Integer.parseInt(showInfo1.idtxt.getText());
                    String url = "jdbc:mysql://localhost/bank1?useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC";
            String db_user = "root";
            String db_pass = "1234";
           
            try {
                Connection con = DriverManager.getConnection(url, db_user, db_pass);

               String query="Select * from customer where ID="+IDC;
               
                
                //two lines are important
                Statement s = con.createStatement();
                // Statement s = cont.createStatement();
                 rs = s.executeQuery(query);
                 boolean flag = false ;
                 if(rs.next()){//change it

                    flag=true;
                     showInfo1.txt1.setText((String) rs.getObject("name"));
                     int idd=(int) rs.getObject("ID");
                     String bd=Integer.toString((int) idd);
                     showInfo1.txt2.setText(bd);
                     showInfo1.txt3.setText((String) rs.getObject("Address"));
                     showInfo1.txt5.setText((String) rs.getObject("Email"));
                     showInfo1.txt8.setText((String) rs.getObject("DOB"));
                     double b=(double) rs.getObject("balance");
                     String bb=Integer.toString((int) b);
                     showInfo1.txt7.setText(bb);
                     showInfo1.txt4.setText((String) rs.getObject("phone"));
                     showInfo1.txt6.setText((String) rs.getObject("password"));
                 
                 }//until here
                 if(flag == false)
                           JOptionPane.showMessageDialog(rootPane,"ID not correct!!!","Error",JOptionPane.ERROR_MESSAGE);
            
                 
                 
               

            } catch (SQLException ex) {
                System.out.println(ex.getMessage());
            }
            
           
       }
               else if (showInfo1.EmployeeRadioButton2.isSelected()){
                   int IDC=Integer.parseInt(showInfo1.idtxt.getText());
                    String url = "jdbc:mysql://localhost/bank1?useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC";
            String db_user = "root";
            String db_pass = "1234";
           
            try {
                Connection con = DriverManager.getConnection(url, db_user, db_pass);

               String query="Select * from employee where id="+IDC;
               
                
                //two lines are important
                Statement s = con.createStatement();
                // Statement s = cont.createStatement();
                 rs = s.executeQuery(query);
                 boolean flag = false ;
                 if(rs.next()){//change it

                    flag=true;
                     showInfo1.txt1.setText((String) rs.getObject("name"));
                      int idd=(int) rs.getObject("id");
                     String bd=Integer.toString((int) idd);
                     showInfo1.txt2.setText(bd);
                     showInfo1.txt3.setText((String) rs.getObject("address"));
                     showInfo1.txt4.setText((String) rs.getObject("phone"));
                     showInfo1.txt5.setText((String) rs.getObject("email"));
                     showInfo1.txt6.setText((String) rs.getObject("password"));
                     showInfo1.txt7.setText((String) rs.getObject("Gender"));
                     showInfo1.txt8.setVisible(false);
                     showInfo1.lblchange.setVisible(false);
 
                 }//until here
                 if(flag == false)
                           JOptionPane.showMessageDialog(rootPane,"ID not correct!!!","Error",JOptionPane.ERROR_MESSAGE);
            
                 
                 
               

            } catch (SQLException ex) {
                System.out.println(ex.getMessage());
            }
            
       }
               else{
                     JOptionPane.showMessageDialog(rootPane,"You have to choose either customer or employee!!!","Error",JOptionPane.ERROR_MESSAGE);
            
               }
               
       }
            }
                      
        );
       showInfo1.deletebtn.addMouseListener(new MouseAdapter(){

            @Override
            public void mouseClicked(MouseEvent e) {
            String url = "jdbc:mysql://localhost/bank1?useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC";
            String db_user = "root";
            String db_pass = "1234";
            try {
                Connection con = DriverManager.getConnection(url, db_user, db_pass);
                
                int xID = Integer.parseInt(showInfo1.idtxt.getText());
                if (showInfo1.CustomerRadioButton.isSelected()){
            
              
                String query="Select * from `bank1`.`customer` where ID="+xID;
                
                Statement s = con.createStatement();
                // Statement s = cont.createStatement();
                 rs = s.executeQuery(query);
       
               String sql = String.format("Delete from `bank1`.`customer` where ID="+xID);
               
               String Hquery="Delete from `bank1`.`history` where custID="+xID;
                
                //Statement s = con.createStatement();
                // Statement s = cont.createStatement();
                  s.executeUpdate(Hquery);
       
               //String Hsql = String.format("Delete from `bank1`.`history` where custID="+xID);
               
                //s = con.createStatement();
                //use with insert , delete , update
                s.executeUpdate(sql);
                //s.executeUpdate(Hsql);
                
                
               JOptionPane.showMessageDialog(null, "Deleted!!! ");
                }
                else if (showInfo1.EmployeeRadioButton2.isSelected()){
                     String query="Select * from `bank1`.`employee` where id="+xID;
                
                Statement s = con.createStatement();
                // Statement s = cont.createStatement();
                 rs = s.executeQuery(query);
       
               String sql = String.format("Delete from `bank1`.`employee` where id="+xID);
               
               String Hquery="Select * from `bank1`.`history` where custID="+xID;
                
                //Statement s = con.createStatement();
                // Statement s = cont.createStatement();
                 rs = s.executeQuery(Hquery);
       
               //String Hsql = String.format("Delete from `bank1`.`history` where custID="+xID);
               
                //s = con.createStatement();
                //use with insert , delete , update
                s.executeUpdate(sql);
                //s.executeUpdate(Hsql);
                
                
               JOptionPane.showMessageDialog(null, "Employee DELETED!");
                }
                else
                    JOptionPane.showMessageDialog(rootPane,"You have to choose either customer or employee!!!","Error",JOptionPane.ERROR_MESSAGE);
                
            }
            
            catch (SQLException ex) {
                System.out.println(ex.getMessage());
            }
               }});
       
       this.creatEmployee1.creatbtn.addMouseListener(new MouseAdapter(){
            @Override
            public void mouseClicked(MouseEvent e) {
                super.mouseClicked(e); //To change body of generated methods, choose Tools | Templates.
                 
            String url = "jdbc:mysql://localhost/bank1?useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC";
            String db_user = "root";
            String db_pass = "1234";
            try {
                Connection con = DriverManager.getConnection(url, db_user, db_pass);

                //register a user
                int xID = Integer.parseInt(creatEmployee1.idtxt.getText());
                String xname = creatEmployee1.nametxt.getText();
                String xpass = creatEmployee1.passtxt.getText();
                String xphone = creatEmployee1.phonetxt.getText();
                String xemail = creatEmployee1.emailtxt.getText();
                String xaddress = creatEmployee1.addrtxt.getText();
                String xgender = creatEmployee1.GenderComboBox.getSelectedItem().toString();
           
                String sql = String.format("Insert into employee"
                        + "(id,name,address,phone,Email,password,Gender)"
                        + "values('%s','%s','%s','%s','%s','%s','%s');", xID,xname,
                        xaddress, xphone, xemail, xpass,xgender);
                //two lines are important
                Statement s = con.createStatement();
                //use with insert , delete , update
                s.executeUpdate(sql);

            } catch (SQLException ex) {
                System.out.println(ex.getMessage());
            }  
     }});
       
       this.showInfo1.upfatebtn.addMouseListener(new MouseAdapter(){
            @Override
            public void mouseClicked(MouseEvent e) {
                super.mouseClicked(e); //To change body of generated methods, choose Tools | Templates.
                
            String url = "jdbc:mysql://localhost/bank1?useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC";
         String db_user = "root";
            String db_pass = "1234";
            try {
                Connection con = DriverManager.getConnection(url, db_user, db_pass);

                //register a user
                int xID = Integer.parseInt(showInfo1.idtxt.getText());
                if (showInfo1.EmployeeRadioButton2.isSelected()){
               // String xusername= tus.getText();
                String xname = showInfo1.txt1.getText();
                String xpass = showInfo1.txt6.getText();
               
                 String xphone = showInfo1.txt4.getText();
                String xemail = showInfo1.txt5.getText();
                String xaddress = showInfo1.txt3.getText();
                String xgender = showInfo1.txt7.getText();

                  String sql = "Update `bank1`.`employee` set name='"+xname+"',address='"+xaddress+"',phone='"+xphone+"',Email='"+xemail+"',password='"+xpass+"',Gender='"+xgender+"' where ID="+xID;
                        Statement s = con.createStatement(); 

                s.executeUpdate(sql);

                JOptionPane.showMessageDialog(null, "The data is UPDATED!");}
                else if (showInfo1.CustomerRadioButton.isSelected()){
                    String xxID=showInfo1.txt2.getText();
               String xname = showInfo1.txt1.getText();
                String xpass = showInfo1.txt6.getText();
               
                 String xphone = showInfo1.txt4.getText();
                String xemail = showInfo1.txt5.getText();
                String xaddress = showInfo1.txt3.getText();
                String xbalance = showInfo1.txt7.getText();
                String xDOB=showInfo1.txt8.getText();
           
                  String sql = "Update `bank1`.`customer` set name='"+xname+"',Address='"+xaddress+"',Email='"+xemail+"',DOB='"+xDOB+"',password='"+xpass+"',balance='"+xbalance+"', phone="+xphone+" where ID="+xxID;
                        Statement s = con.createStatement(); 
      
                s.executeUpdate(sql);

                JOptionPane.showMessageDialog(null, "The data is UPDATED!");
                }
                else
                    JOptionPane.showMessageDialog(rootPane,"You have to choose either customer or employee!!!","Error",JOptionPane.ERROR_MESSAGE);
                
            } catch (SQLException ex) {
                System.out.println(ex.getMessage());
            }
            }
           
       });
       
       this.openC1.registerbtn.addMouseListener(new MouseAdapter(){

            @Override
            public void mouseClicked(MouseEvent e) {
                super.mouseClicked(e); //To change body of generated methods, choose Tools | Templates.
                String url = "jdbc:mysql://localhost/bank1?useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC";
            String db_user = "root";
            String db_pass = "1234";
            try {
                Connection con = DriverManager.getConnection(url, db_user, db_pass);

                //register a user
                int xID = Integer.parseInt(openC1.idtxt.getText());
                String xname = openC1.nametxt.getText();
                String xpass = openC1.passtxt.getText();
                String xphone = openC1.phonetxt.getText();
                String xemail = openC1.emailtxt.getText();
                String xaddress = openC1.addrtxt.getText();
                String xDOB = openC1.dobtxt.getText();
           
                String sql = String.format("Insert into customer"
                        + "(ID,name,Address,Email,DOB,password,phone)"
                        + "values('%s','%s','%s','%s','%s','%s','%s');", xID,xname,
                        xaddress, xemail, xDOB, xpass,xphone);
                //two lines are important
                Statement s = con.createStatement();
                //use with insert , delete , update
                s.executeUpdate(sql);

            } catch (SQLException ex) {
                System.out.println(ex.getMessage());
            }
            }
           
       });
       
       this.deleteC1.deletbtn.addMouseListener(new MouseAdapter(){

            @Override
            public void mouseClicked(MouseEvent e) {
                super.mouseClicked(e); //To change body of generated methods, choose Tools | Templates.
                  String url = "jdbc:mysql://localhost/bank1?useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC";
            String db_user = "root";
            String db_pass = "1234";
            try {
                Connection con = DriverManager.getConnection(url, db_user, db_pass);
                
                int xID = Integer.parseInt(deleteC1.usertxt.getText());
                
                      
              
                String query="Select * from `bank1`.`customer` where ID="+xID;
                
                Statement s = con.createStatement();
                // Statement s = cont.createStatement();
                 rs = s.executeQuery(query);
       
               String sql = String.format("Delete from `bank1`.`customer` where ID="+xID);
               
               String Hquery="Delete from `bank1`.`history` where custID="+xID;
                
                //Statement s = con.createStatement();
                // Statement s = cont.createStatement();
                  s.executeUpdate(Hquery);
       
               //String Hsql = String.format("Delete from `bank1`.`history` where custID="+xID);
               
                //s = con.createStatement();
                //use with insert , delete , update
                s.executeUpdate(sql);
                //s.executeUpdate(Hsql);

               JOptionPane.showMessageDialog(null, "Deleted!!! ");}
            catch (SQLException ex) {
                System.out.println(ex.getMessage());
            }
  
           
      } });
       
       this.updateCustomerC1.updatebtn.addMouseListener(new MouseAdapter(){

            @Override
            public void mouseClicked(MouseEvent e) {
                super.mouseClicked(e); //To change body of generated methods, choose Tools | Templates.
                String url = "jdbc:mysql://localhost/bank1?useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC";
         String db_user = "root";
            String db_pass = "1234";
            try {
                Connection con = DriverManager.getConnection(url, db_user, db_pass);

                //register a user
                int xID = Integer.parseInt(loginCustomerPage1.nametxt.getText());
                
               // String xusername= tus.getText();
                String xname = updateCustomerC1.nametxt.getText();
                String xpass = updateCustomerC1.passwordtxt.getText();
               
                 String xphone = updateCustomerC1.phonetxt.getText();
                String xemail = updateCustomerC1.emailtxt.getText();
                String xaddress = updateCustomerC1.addresstxt.getText();
                String xdob = updateCustomerC1.DOBtxt.getText();
                

                  String sql = "Update `bank1`.`customer` set name='"+xname+"',Address='"+xaddress+"',phone='"+xphone+"',Email='"+xemail+"',password='"+xpass+"',DOB='"+xdob+"' where ID="+xID;
                        Statement s = con.createStatement(); 

                s.executeUpdate(sql);

                JOptionPane.showMessageDialog(null, "The data is UPDATED!");
                   
                
            }catch (SQLException ex) {
                System.out.println(ex.getMessage());
            }
           
            }
       });
       
       this.viewC1.submitbtn.addMouseListener(new MouseAdapter(){

            @Override
            public void mouseClicked(MouseEvent e) {
                super.mouseClicked(e); //To change body of generated methods, choose Tools | Templates.
                if(viewC1.transactionare.getText()==null){
                String url = "jdbc:mysql://localhost/bank1?useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC";
                String db_user = "root";
                String db_pass = "1234";
            try {
                Connection con = DriverManager.getConnection(url, db_user, db_pass);
                // Connection conr = DriverManager.getConnection(url, db_user, db_pass);
                
                int xID = Integer.parseInt(viewC1.usertxt.getText());

                Statement s = con.createStatement();
                Statement r= con.createStatement();

                 rs = s.executeQuery("Select * from `bank1`.`history` where custID="+xID );
                 trs= r.executeQuery("Select * from `bank1`.`customer` where ID="+xID);
                
                 if(trs.next()){
                    viewC1.nametxt.setText( trs.getString("name"));
                 viewC1.phonetxt.setText( trs.getString("phone"));
                }
                 
                 
                 String st="ID       Type       Amount    OtherAccount  \n----------------------------------------------\n";
                 viewC1.transactionare.append(st);
                 while(rs.next()){
                 int id=rs.getInt("custID");
                 String type=rs.getString("type");
                 Double amount=rs.getDouble("amount");
                 String other=rs.getString("otherAccount");

                 String stt=id+"       "+type+"      "+amount+"           "+other+
                         "   ";
                 viewC1.transactionare.append(stt+"\n");
                 

                 }
                

            }
            catch (SQLException ex) {
                System.out.println(ex.getMessage());
            }
                }
               else{
                    String url = "jdbc:mysql://localhost/bank1?useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC";
                String db_user = "root";
                String db_pass = "1234";
                    viewC1.transactionare.setText("");
                    viewC1.nametxt.setText("");
                    viewC1.phonetxt.setText("");
                    try {
                Connection con = DriverManager.getConnection(url, db_user, db_pass);
                // Connection conr = DriverManager.getConnection(url, db_user, db_pass);
                
                int xID = Integer.parseInt(viewC1.usertxt.getText());

                Statement s = con.createStatement();
                Statement r= con.createStatement();

                 rs = s.executeQuery("Select * from `bank1`.`history` where custID="+xID );
                 trs= r.executeQuery("Select * from `bank1`.`customer` where ID="+xID);
                
                 if(trs.next()){
                    viewC1.nametxt.setText( trs.getString("name"));
                 viewC1.phonetxt.setText( trs.getString("phone"));
                }
                 
                 
                 String st="ID       Type       Amount    OtherAccount  \n----------------------------------------------\n";
                 viewC1.transactionare.append(st);
                 while(rs.next()){
                 int id=rs.getInt("custID");
                 String type=rs.getString("type");
                 Double amount=rs.getDouble("amount");
                 String other=rs.getString("otherAccount");

                 String stt=id+"       "+type+"      "+amount+"           "+other+
                         "   ";
                 viewC1.transactionare.append(stt+"\n");
                 

                 }
                

            }
            catch (SQLException ex) {
                System.out.println(ex.getMessage());
            }
                    
                }
                
            }});
       
         
      
       
     
    }
    

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        updateCustomerC1 = new bankmanagment.UpdateCustomerC();
        displayTransaction1 = new bankmanagment.DisplayTransaction();
        managerPage1 = new bankmanagment.ManagerPage();
        showInfo1 = new bankmanagment.ShowInfo();
        deleteC1 = new bankmanagment.DeleteC();
        openC1 = new bankmanagment.OpenC();
        viewC1 = new bankmanagment.ViewC();
        afTransfer1 = new bankmanagment.AfTransfer();
        transaction1 = new bankmanagment.Transaction();
        withdraw1 = new bankmanagment.Withdraw();
        afDeposit2 = new bankmanagment.AfDeposit();
        deposit1 = new bankmanagment.Deposit();
        transactionPage1 = new bankmanagment.TransactionPage();
        customerPage2 = new bankmanagment.CustomerPage();
        registerCustomerPage1 = new bankmanagment.RegisterCustomerPage();
        loginEmployeePage1 = new bankmanagment.LoginEmployeePage();
        loginCustomerPage1 = new bankmanagment.LoginCustomerPage();
        creatEmployee1 = new bankmanagment.CreatEmployee();
        transactionShown1 = new bankmanagment.TransactionShown();
        employeePage1 = new bankmanagment.EmployeePage();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setMaximumSize(new java.awt.Dimension(840, 514));
        setMinimumSize(new java.awt.Dimension(840, 514));
        setPreferredSize(new java.awt.Dimension(840, 500));
        setResizable(false);
        getContentPane().setLayout(null);

        updateCustomerC1.setMaximumSize(new java.awt.Dimension(800, 514));
        updateCustomerC1.setMinimumSize(new java.awt.Dimension(800, 514));
        getContentPane().add(updateCustomerC1);
        updateCustomerC1.setBounds(-4, 0, 840, 500);

        displayTransaction1.setMaximumSize(new java.awt.Dimension(840, 500));
        displayTransaction1.setMinimumSize(new java.awt.Dimension(840, 500));

        javax.swing.GroupLayout displayTransaction1Layout = new javax.swing.GroupLayout(displayTransaction1);
        displayTransaction1.setLayout(displayTransaction1Layout);
        displayTransaction1Layout.setHorizontalGroup(
            displayTransaction1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 1010, Short.MAX_VALUE)
        );
        displayTransaction1Layout.setVerticalGroup(
            displayTransaction1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 520, Short.MAX_VALUE)
        );

        getContentPane().add(displayTransaction1);
        displayTransaction1.setBounds(-170, -20, 1010, 520);

        managerPage1.setMaximumSize(new java.awt.Dimension(840, 500));
        managerPage1.setMinimumSize(new java.awt.Dimension(840, 500));
        getContentPane().add(managerPage1);
        managerPage1.setBounds(0, 0, 840, 500);

        showInfo1.setMaximumSize(new java.awt.Dimension(840, 500));
        showInfo1.setMinimumSize(new java.awt.Dimension(840, 500));
        getContentPane().add(showInfo1);
        showInfo1.setBounds(0, 0, 840, 500);

        deleteC1.setMaximumSize(new java.awt.Dimension(840, 500));
        deleteC1.setMinimumSize(new java.awt.Dimension(840, 500));
        getContentPane().add(deleteC1);
        deleteC1.setBounds(0, 0, 840, 500);

        openC1.setMaximumSize(new java.awt.Dimension(840, 500));
        openC1.setMinimumSize(new java.awt.Dimension(840, 500));
        getContentPane().add(openC1);
        openC1.setBounds(0, 0, 840, 500);

        viewC1.setMaximumSize(new java.awt.Dimension(840, 500));
        viewC1.setMinimumSize(new java.awt.Dimension(840, 500));
        getContentPane().add(viewC1);
        viewC1.setBounds(0, 0, 840, 500);

        afTransfer1.setMaximumSize(new java.awt.Dimension(840, 519));
        afTransfer1.setMinimumSize(new java.awt.Dimension(840, 519));
        getContentPane().add(afTransfer1);
        afTransfer1.setBounds(0, 0, 840, 500);

        transaction1.setMaximumSize(new java.awt.Dimension(840, 519));
        transaction1.setMinimumSize(new java.awt.Dimension(840, 519));
        getContentPane().add(transaction1);
        transaction1.setBounds(0, 0, 840, 500);

        withdraw1.setMaximumSize(new java.awt.Dimension(840, 519));
        withdraw1.setMinimumSize(new java.awt.Dimension(840, 519));
        getContentPane().add(withdraw1);
        withdraw1.setBounds(0, 0, 840, 500);

        afDeposit2.setMaximumSize(new java.awt.Dimension(840, 500));
        afDeposit2.setMinimumSize(new java.awt.Dimension(840, 500));
        getContentPane().add(afDeposit2);
        afDeposit2.setBounds(0, 0, 840, 500);

        deposit1.setMaximumSize(new java.awt.Dimension(840, 519));
        deposit1.setMinimumSize(new java.awt.Dimension(840, 519));
        getContentPane().add(deposit1);
        deposit1.setBounds(0, 11, 840, 490);

        transactionPage1.setMaximumSize(new java.awt.Dimension(840, 519));
        transactionPage1.setMinimumSize(new java.awt.Dimension(840, 519));
        getContentPane().add(transactionPage1);
        transactionPage1.setBounds(0, 0, 840, 500);

        customerPage2.setMaximumSize(new java.awt.Dimension(840, 519));
        customerPage2.setMinimumSize(new java.awt.Dimension(840, 519));
        getContentPane().add(customerPage2);
        customerPage2.setBounds(0, 0, 840, 500);

        registerCustomerPage1.setMaximumSize(new java.awt.Dimension(840, 519));
        registerCustomerPage1.setMinimumSize(new java.awt.Dimension(840, 519));
        getContentPane().add(registerCustomerPage1);
        registerCustomerPage1.setBounds(0, -20, 840, 519);

        loginEmployeePage1.setMaximumSize(new java.awt.Dimension(840, 519));
        loginEmployeePage1.setMinimumSize(new java.awt.Dimension(840, 519));
        getContentPane().add(loginEmployeePage1);
        loginEmployeePage1.setBounds(0, 0, 840, 500);

        loginCustomerPage1.setForeground(new java.awt.Color(204, 204, 204));
        loginCustomerPage1.setMaximumSize(new java.awt.Dimension(840, 519));
        loginCustomerPage1.setMinimumSize(new java.awt.Dimension(840, 519));
        getContentPane().add(loginCustomerPage1);
        loginCustomerPage1.setBounds(0, -20, 840, 520);

        creatEmployee1.setMaximumSize(new java.awt.Dimension(840, 519));
        creatEmployee1.setMinimumSize(new java.awt.Dimension(840, 519));
        getContentPane().add(creatEmployee1);
        creatEmployee1.setBounds(0, 0, 840, 500);

        transactionShown1.setMaximumSize(new java.awt.Dimension(840, 519));
        transactionShown1.setMinimumSize(new java.awt.Dimension(840, 519));
        getContentPane().add(transactionShown1);
        transactionShown1.setBounds(0, 0, 840, 500);

        employeePage1.setMaximumSize(new java.awt.Dimension(840, 500));
        employeePage1.setMinimumSize(new java.awt.Dimension(840, 500));
        getContentPane().add(employeePage1);
        employeePage1.setBounds(0, 0, 840, 500);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(MyFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(MyFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(MyFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(MyFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new MyFrame().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private bankmanagment.AfDeposit afDeposit2;
    private bankmanagment.AfTransfer afTransfer1;
    private bankmanagment.CreatEmployee creatEmployee1;
    private bankmanagment.CustomerPage customerPage2;
    private bankmanagment.DeleteC deleteC1;
    private bankmanagment.Deposit deposit1;
    private bankmanagment.DisplayTransaction displayTransaction1;
    private bankmanagment.EmployeePage employeePage1;
    private bankmanagment.LoginCustomerPage loginCustomerPage1;
    private bankmanagment.LoginEmployeePage loginEmployeePage1;
    private bankmanagment.ManagerPage managerPage1;
    private bankmanagment.OpenC openC1;
    private bankmanagment.RegisterCustomerPage registerCustomerPage1;
    private bankmanagment.ShowInfo showInfo1;
    private bankmanagment.Transaction transaction1;
    private bankmanagment.TransactionPage transactionPage1;
    private bankmanagment.TransactionShown transactionShown1;
    private bankmanagment.UpdateCustomerC updateCustomerC1;
    private bankmanagment.ViewC viewC1;
    private bankmanagment.Withdraw withdraw1;
    // End of variables declaration//GEN-END:variables
}
